
// Developer Info - Arjun (https://github.com/arjun0108)

$(document).ready(function(){
	$('#myBtn').click(function(event){
		showModal();
		event.stopPropagation(); 
	});
	$('#modalClose').click(function(){
		hideModal();
	});
	
	// Do nothing when clicking on the modal content
	$('.modal-content').click(function(event){
       event.stopPropagation(); 
    });
});

function showModal(){
	$('#myModal').fadeIn('fast');
		(function fun(){
			$('.modal-content').css({'transform':'translateX(0px)'});
		})();
}

function hideModal(){
	$('#myModal').fadeOut('fast');
		(function fun2(){
			$('.modal-content').css({ 'transform':'translateX(50px)' });
		})();
}



$(document).on("click", function () {
    //click outside of ".nav__dropdown" class itself and menu will be hidden
	hideModal();
});